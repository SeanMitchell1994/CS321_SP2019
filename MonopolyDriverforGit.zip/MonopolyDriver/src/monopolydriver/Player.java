/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package monopolydriver;
// ========================================
// Player.java
// Main class for the player objects
// ========================================

// Imports
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.swing.ImageIcon;
import java.util.ArrayList;
import java.util.Scanner;
import javax.imageio.ImageIO;
import javax.swing.JLabel;

public class Player{
	// Member Variables

	private int location;
	private int money;
	//private int[] property_list;
	//ArrayList<Property> property_list = new ArrayList<>();
        ArrayList<Tile_Adapter> property_list = new ArrayList<>();
	private ImageIcon image;
	private String name;
	private boolean is_ready;
	// list with money broken down into types of money
	// integer that shows the sum total of money

	// Default constructor
	public Player(String input_name, int whichP)
	{
            System.out.print("Player created!\n");

	    location = 0;		// starting location
            name = input_name;	// player name as a string
	    money = 1500;		// temp variable, this will change
	    is_ready = false;	// is the player ready to move to the next
             
             if(whichP == 1){
                 File imageFile = new File("Fadora.PNG");
                 BufferedImage tokinImage = new BufferedImage(50, 50, BufferedImage.TYPE_INT_ARGB);
                 try{
                    tokinImage = ImageIO.read(imageFile);
                    } 
                catch(IOException e){
                    System.out.println("Error: " + e);
                    }
            image = new ImageIcon(tokinImage);
            }
             if(whichP == 2){
                 File imageFile = new File("Beaker.PNG");
                 BufferedImage tokinImage = new BufferedImage(50, 50, BufferedImage.TYPE_INT_ARGB);
                 try{
                    tokinImage = ImageIO.read(imageFile);
                    } 
                catch(IOException e){
                    System.out.println("Error: " + e);
                    }
            image = new ImageIcon(tokinImage);
            }
             if(whichP == 3){
                 File imageFile = new File("Glasses.PNG");
                 BufferedImage tokinImage = new BufferedImage(50, 50, BufferedImage.TYPE_INT_ARGB);
                 try{
                    tokinImage = ImageIO.read(imageFile);
                    } 
                catch(IOException e){
                    System.out.println("Error: " + e);
                    }
            image = new ImageIcon(tokinImage);
            }
             if(whichP != 1 && whichP != 2 && whichP != 3){
                 File imageFile = new File("Horse.PNG");
                 BufferedImage tokinImage = new BufferedImage(50, 50, BufferedImage.TYPE_INT_ARGB);
                 try{
                    tokinImage = ImageIO.read(imageFile);
                    } 
                catch(IOException e){
                    System.out.println("Error: " + e);
                    }
            image = new ImageIcon(tokinImage);
            }
	} 

	// ==================================
	// Accessor Functions
	// ==================================
	// Returns location as an int
	public int Get_Location(){
                return this.location;
	}
	// Returns current player money as an int
	public int Get_Money(){
               return this.money;
	}
        // Returns player's name as a string
	public String Get_Name(){
            return this. name;
	}

	// returns if the player is done with their turn
	public boolean Is_Ready(){
            return this.is_ready;
	}
        
        public ImageIcon Get_Image(){
            return this.image;
        }
        
        public int Get_YCordinate(){
        int starty = 545;
        if(location <= 10 && location >= 0){
            return starty;
        }
        if(location < 30 && location >= 20 ){
            starty = 50;
            return starty;
        }
            
        if(Get_Location() == 11 || Get_Location() == 39){return 500;}
        if(Get_Location() == 12 || Get_Location() == 38){return 470;}
        if(Get_Location() == 13 || Get_Location() == 37){return 440;}
        if(Get_Location() == 14 || Get_Location() == 36){return 400;}
        if(Get_Location() == 15 || Get_Location() == 35){return 370;}
        if(Get_Location() == 16 || Get_Location() == 34){return 335;}
        if(Get_Location() == 17 || Get_Location() == 33){return 300;}
        if(Get_Location() == 18 || Get_Location() == 32){return 260;}
        if(Get_Location() == 19 || Get_Location() == 31){return 220;}        
            
            return 0;
        }
        
        public int Get_XCordinate(){
            int startx = 750;
            if(Get_Location() == 0){ return startx;}
            if(Get_Location() == 1 || Get_Location() == 29){return 730;}
            if(Get_Location() == 2 || Get_Location() == 28){return 670;}
            if(Get_Location() == 3 || Get_Location() == 27){return 590;}
            if(Get_Location() == 4 || Get_Location() == 26){return 500;}
            if(Get_Location() == 5 || Get_Location() == 25){return 420;}
            if(Get_Location() == 6 || Get_Location() == 24){return 365;}
            if(Get_Location() == 7 || Get_Location() == 23){return 300;}
            if(Get_Location() == 8 || Get_Location() == 22){return 260;}
            if(Get_Location() == 9 || Get_Location() == 21){return 220;}
            
            if(Get_Location() >= 10 && location < 20){
                return 170;
            }
            if(Get_Location() >= 30 && location < 40){
                return 770;
            }
            return 0;
        }

	

	// ==================================
	// Mutator Functions
	// ==================================
     
	/**
	* Sets the player's location as an int
	*
	* @param  input  an integer representing the location of the player
	* @return      None
	*/
	public void Set_Location(int input){
            location = location + input;
	}
        /**
	* changes a players location based on a value passed in
	*
	* @param  	shift  The amount to shift the player's location by
	* @return      	None
	*/
        public void Shift_Location(int shift){
            if((Get_Location() + shift) > 39){
                Set_Location(((Get_Location()+shift) - 40));
                Set_Money(Get_Money()+200);
            }
            else if((Get_Location() + shift) < 0){
                Set_Location(40+(Get_Location()+shift));
            }
            else{
                Set_Location(Get_Location()+shift);
            }
        }

	/**
	* Sets the player's money to the given input
	*
	* @param  input  an integer representing the player's money
	* @return      None
	*/
	public void Set_Money(int input)
	{
        	money = input;
	}
        
        //shifts a player's money (add/subtraction)
        //needs an if to call morgage/forfiet option when money reaches below zero
        public void shift_Money(int input){
            money = money + input;
        }

	/**
	* Sets the player's name to the given input
	*
	* @param  input  a string representing the player's name
	* @return      None
	*/
	public void Set_Name(String input){
            name = input;
	}

	
	/**
	* Sets if the player is ready to end their turn
	*
	* @param  	None
	* @return      	None
	*/
	public void Set_Ready(){
            is_ready = true;
	}
        
	/**
	* Sets the image used for the player's token
	*
	* @param  	x	A loaded image file
	* @return      	None
	*/
        public void Set_Image(ImageIcon x){
            image = x;
        }
/**
	* Allows the player to buy a property
	* Adds the property object to the player's property list 
	* and subtracts the cost of the property from the player's current money
	*
	* @param  	tile	A property object
	* @return      	None
	*/
	public void Buy_Property(Tile_Adapter tile){
            // to do: check if player already owns tile
            System.out.print("Buy function!\n");
            if (tile.getType() == 1)
                if (!tile.Get_IsOwned())
                {                                //THERE WAS AN ERROR THERE WAS AN ERRORTHERE WAS AN ERROR THERE WAS AN ERROR THERE WAS AN ERROR THERE WAS AN ERROR THERE WAS AN ERROR
                    property_list.add(tile);   //THERE WAS AN ERROR THERE WAS AN ERROR THERE WAS AN ERROR THERE WAS AN ERROR THERE WAS AN ERROR THERE WAS AN ERROR
                    tile.Set_IsOwned(true);
                    tile.Set_Owner(this.name);
                    money = money - tile.getPrice();
                }
                else
                    System.out.print("Property is already owned!\n");
        }

	/**
	* Allows the player to sell a property
	* Removes the property object to the player's property list 
	* and adds the cost of the property from the player's current money
	*
	* @param  	tile	A property object
	* @return      	None
	*/
	public void Sell_Property(Tile_Adapter tile){
            System.out.print("Sell detected!\n");
            property_list.remove(tile);
            money = money + tile.getPrice();
	}
     
	public void Trade_Property(Player p_other, Tile_Adapter tile){
		Sell_Property(tile);
		p_other.Buy_Property(tile);	
	}
        
        public void Turn(Tile_Adapter current_tile){
		String s = "";
		System.out.print("Actions: Buy | Sell | Trade\n");
		Scanner sc = new Scanner(System.in);
		s = sc.nextLine();
		if (s.equals("Buy"))
                {
                    this.Buy_Property(current_tile);
                }
		else if (s.equals("Sell"))
                {
                    this.Sell_Property(current_tile);
                }
		else if (s.equals("Trade")){System.out.print("Trade detected!\n");}
            //    else if(s.equals("Debug")){Print_Property();}
        }
        /*
         public void Print_Property(){
            for (int  i = 0; i < property_list.size(); i++){
                System.out.println("Name: " + property_list.get(i).getName());
                System.out.println("Location: "  + property_list.get(i).getLocation());
                System.out.println("Price: " + property_list.get(i).getPrice());
                System.out.println();
            } 
        }
        */
        
        public void Turn()
	{
		String s = "";
		System.out.print("Actions: Buy | Sell | Trade\n");
		Scanner sc = new Scanner(System.in);
		s = sc.nextLine();
		if (s.equals("Buy")){System.out.print("Buy detected!\n");}
		else if (s.equals("Sell")){System.out.print("Sell detected!\n");}
		else if (s.equals("Trade")){System.out.print("Trade detected!\n");}
	}
        public int PlayerRoll(){
            int rollValue = (new Dice_Roller(12).Roll());
           // Shift_Location(rollValue);
            System.out.println("The Player Rolled a: "+ rollValue);
            return rollValue;
        }
}