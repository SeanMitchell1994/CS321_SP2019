/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package monopolydriver;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.FlowPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author MeganHaskins
 */
public class View1 extends Mdriver{
    Board gameBoard;
    int turnCounter;
    
 public void View1(){  turnCounter = 0; }
    
  public void welcomeMenu(){
        Button btnStart = new Button();
        Button btnInstructions = new Button();
        Button btnExit = new Button();
        btnInstructions.setText("Instructions");
        btnStart.setText("Start Game");
        btnExit.setText("Exit Game");
        
        //Exit Event
         btnExit.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                System.out.println("Exit Program");
            }
        });
         
         //Instruction Event
        btnInstructions.setOnAction(new EventHandler<ActionEvent>() {
            @Override
              public void handle(ActionEvent event) { 
                  instructionEvent();
            }         
        });
        
        //Start Event
        btnStart.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                setupMenu();
            }
        });   
        
        FlowPane root = new FlowPane();
        root.getChildren().add(btnStart);
        root.getChildren().add(btnInstructions);
        root.getChildren().add(btnExit);
        
        Scene Startscene = new Scene(root, 400, 350);
        Stage welcomeMenu = new Stage();
        welcomeMenu.setTitle("UAH Monopoly Start Menu");
        welcomeMenu.setScene(Startscene);
        
        welcomeMenu.show();
    }
  
  public void instructionEvent(){
       System.out.println("Give Instructions");
                
       JPanel panel = new JPanel();
       panel.setPreferredSize(new Dimension(1000,1000));
       JLabel instructionText = new JLabel("These are the Instructions to play: \n win");
       panel.add(instructionText);

       JFrame frame = new JFrame("Instructions");
       frame.getContentPane().add(panel);
       frame.pack();
       frame.setVisible(true);  
    }
    
    //Will be edited to display current player locations
    public void viewBoard(Player currentP){
       JFrame frame = new JFrame();
       JPanel basePanel = new JPanel();
       JLayeredPane lpane = new JLayeredPane();
       JPanel boardPanel = new JPanel();
       JPanel controlPanel = new JPanel();
       controlPanel.setLayout(new FlowLayout());
       JButton btnRollDice = new JButton("Roll Dice");
       JButton btnManageProperty = new JButton("Manage Property");
       Button btnViewBoard = new Button("View Board");
       Button btnEndTurn = new Button("End Turn");
       Button btnForfeit = new Button("Forfiet");
       JTextField turnInfo = new JTextField("I will place info here");
       controlPanel.add(btnRollDice);
       controlPanel.add(btnRollDice);
 
       boardPanel.setPreferredSize(new Dimension(1000,800));
       //
        //get board image
       //
        File imageFile = new File("Board.JPG");
        BufferedImage boardImage = new BufferedImage(400, 400, BufferedImage.TYPE_INT_ARGB);
           try{
           boardImage = ImageIO.read(imageFile);
             } 
          catch(IOException e){
             System.out.println("Error: " + e);
             }
        JLabel photoLabel = new JLabel(new ImageIcon(boardImage));
        boardPanel.add(photoLabel);
       
        JPanel tokinPanel1 = new JPanel();
        JPanel tokinPanel2 = new JPanel();
        JPanel tokinPanel3 = new JPanel();
        JPanel tokinPanel4 = new JPanel();
        //Get tokin Image
       /* JLabel tokinPhoto1 = new JLabel(gameBoard.get_Player(0).Get_Image());
        tokinPanel1.add(tokinPhoto1); 
        JLabel tokinPhoto2 = new JLabel(gameBoard.get_Player(1).Get_Image());
        tokinPanel2.add(tokinPhoto2); 
        JLabel tokinPhoto3 = new JLabel(gameBoard.get_Player(2).Get_Image());
        tokinPanel3.add(tokinPhoto1); 
        JLabel tokinPhoto4 = new JLabel(gameBoard.get_Player(3).Get_Image());
        tokinPanel4.add(tokinPhoto1);         
        */
        
        basePanel.setPreferredSize(new Dimension(1500, 1000));
        basePanel.setLayout(new BorderLayout());
        basePanel.add(lpane, BorderLayout.CENTER);
        basePanel.add(controlPanel, BorderLayout.SOUTH);
        lpane.setBounds(0, 0, 900, 900);
        boardPanel.setBackground(Color.BLUE);
        boardPanel.setBounds(0, 0, 900, 900);
        boardPanel.setOpaque(true);
        tokinPanel1.setBackground(Color.GREEN);
        tokinPanel2.setBackground(Color.BLUE);
        tokinPanel3.setBackground(Color.BLACK);
        tokinPanel4.setBackground(Color.YELLOW);
        
        //needs to be editable
        tokinPanel1.setBounds(gameBoard.get_Player(0).Get_XCordinate(), gameBoard.get_Player(0).Get_YCordinate(), 30, 30);
        tokinPanel2.setBounds(gameBoard.get_Player(1).Get_XCordinate(), gameBoard.get_Player(1).Get_YCordinate(), 30, 30);
        tokinPanel3.setBounds(gameBoard.get_Player(2).Get_XCordinate(), gameBoard.get_Player(2).Get_YCordinate(), 30, 30);
        tokinPanel4.setBounds(gameBoard.get_Player(3).Get_XCordinate(), gameBoard.get_Player(3).Get_YCordinate(), 30, 30);
        tokinPanel1.setOpaque(true); tokinPanel2.setOpaque(true); tokinPanel3.setOpaque(true); tokinPanel4.setOpaque(true);
        lpane.add(boardPanel, new Integer(0), 0);
        lpane.add(tokinPanel4, new Integer(1), 0);
        lpane.add(tokinPanel3, new Integer(1), 0);
        lpane.add(tokinPanel2, new Integer(1), 0);
        lpane.add(tokinPanel1, new Integer(1), 0);
       
        //needs to be updateable
        JPanel panelplease = playerInformation();
        panelplease.setPreferredSize(new Dimension(500, 950));
        
 //Control Menu Buttons
        JPanel controlP = new JPanel();
        JButton btnManageProp = new JButton("Manage Property");
        JButton btnRollDice1 = new JButton("Roll Dice");
        JTextField TFresults = new JTextField(currentP.Get_Name()+" Start Turn");
        btnRollDice1.addActionListener(new ActionListener() { 
            public void actionPerformed(ActionEvent e) { 
             currentP.PlayerRoll();
            } 
           @Override
           public void actionPerformed(java.awt.event.ActionEvent e) {
             int rolled = currentP.PlayerRoll();
             currentP.Shift_Location(rolled);
             TFresults.setText("The player rolled a: " + rolled);
             frame.dispose();
             afterRollBoard(currentP, "The player rolled a: " + rolled);    
           }
        } );
        
        btnManageProp.addActionListener(new ActionListener() { 
            public void actionPerformed(ActionEvent e) { 
             
            } 
           @Override
           public void actionPerformed(java.awt.event.ActionEvent e) {
             managePropertyMenu();              
           }
        } );
        controlP.add(btnManageProp);
        controlP.add(btnRollDice1);
        controlP.add(TFresults);
        
        panelplease.add(controlP);
        basePanel.add(panelplease, BorderLayout.EAST);
        frame.add(basePanel);
        frame.pack();
        frame.setVisible(true);    
    }

     public void afterRollBoard(Player currentP, String rollResult){
        JFrame frame = new JFrame();
        JPanel basePanel = new JPanel();
       JLayeredPane lpane = new JLayeredPane();
       JPanel boardPanel = new JPanel();
       
       JPanel controlPanel = new JPanel();
       controlPanel.setLayout(new FlowLayout());
        JButton btnManageProperty = new JButton("Manage Property");
        JButton btnEndTurn = new JButton("End Turn");
        JButton btnForfeit = new JButton("Forfiet");
        
         btnEndTurn.addActionListener(new ActionListener() { 
            public void actionPerformed(ActionEvent e) { 
            } 
           @Override
           public void actionPerformed(java.awt.event.ActionEvent e) {
             frame.dispose();
             turnCounter++;
             if(turnCounter == 4){
                 turnCounter = 0;
             }
             playerTurns();            
           }
        } );
        
       boardPanel.setPreferredSize(new Dimension(1000,800));
        //get board image
       //
        File imageFile = new File("Board.JPG");
        BufferedImage boardImage = new BufferedImage(400, 400, BufferedImage.TYPE_INT_ARGB);
           try{
           boardImage = ImageIO.read(imageFile);
             } 
          catch(IOException e){
             System.out.println("Error: " + e);
             }
       JLabel photoLabel = new JLabel(new ImageIcon(boardImage));
       boardPanel.add(photoLabel);
       
        JPanel tokinPanel1 = new JPanel();
        JPanel tokinPanel2 = new JPanel();
        JPanel tokinPanel3 = new JPanel();
        JPanel tokinPanel4 = new JPanel();
        
        //Get tokin Image
        /*
        JLabel tokinPhoto1 = new JLabel(gameBoard.get_Player(0).Get_Image());
        tokinPanel1.add(tokinPhoto1); 
        JLabel tokinPhoto2 = new JLabel(gameBoard.get_Player(1).Get_Image());
        tokinPanel2.add(tokinPhoto2); 
        JLabel tokinPhoto3 = new JLabel(gameBoard.get_Player(2).Get_Image());
        tokinPanel3.add(tokinPhoto1); 
        JLabel tokinPhoto4 = new JLabel(gameBoard.get_Player(3).Get_Image());
        tokinPanel4.add(tokinPhoto1); 
                */
        basePanel.setPreferredSize(new Dimension(1500, 1000));
        basePanel.setLayout(new BorderLayout());
        basePanel.add(lpane, BorderLayout.CENTER);
        basePanel.add(controlPanel, BorderLayout.SOUTH);
        lpane.setBounds(0, 0, 900, 900);
        boardPanel.setBackground(Color.BLUE);
        boardPanel.setBounds(0, 0, 900, 900);
        boardPanel.setOpaque(true);
        tokinPanel1.setBackground(Color.GREEN);
        tokinPanel2.setBackground(Color.BLUE);
        tokinPanel3.setBackground(Color.BLACK);
        tokinPanel4.setBackground(Color.YELLOW);
        
        //needs to be editable
        tokinPanel1.setBounds(gameBoard.get_Player(0).Get_XCordinate(), gameBoard.get_Player(0).Get_YCordinate(), 30, 30);
        tokinPanel2.setBounds(gameBoard.get_Player(1).Get_XCordinate(), gameBoard.get_Player(1).Get_YCordinate(), 30, 30);
        tokinPanel3.setBounds(gameBoard.get_Player(2).Get_XCordinate(), gameBoard.get_Player(2).Get_YCordinate(), 30, 30);
        tokinPanel4.setBounds(gameBoard.get_Player(3).Get_XCordinate(), gameBoard.get_Player(3).Get_YCordinate(), 30, 30);
        tokinPanel1.setOpaque(true); tokinPanel2.setOpaque(true); tokinPanel3.setOpaque(true); tokinPanel4.setOpaque(true);
        lpane.add(boardPanel, new Integer(0), 0);
        lpane.add(tokinPanel4, new Integer(1), 0);
        lpane.add(tokinPanel3, new Integer(1), 0);
        lpane.add(tokinPanel2, new Integer(1), 0);
        lpane.add(tokinPanel1, new Integer(1), 0);
       
        //needs to be updateable
        JPanel panelplease = playerInformation();
        panelplease.setPreferredSize(new Dimension(500, 950));
        
 //Control Menu Buttons
        JPanel controlP = new JPanel();
        JButton btnManageProp = new JButton("Manage Property");
        JTextField TFresults = new JTextField(rollResult);
        btnManageProp.addActionListener(new ActionListener() { 
            public void actionPerformed(ActionEvent e) { 
             
            } 
           @Override
           public void actionPerformed(java.awt.event.ActionEvent e) {
             managePropertyMenu();   
           }
        } );      
        controlP.add(btnManageProp);
        controlP.add(btnEndTurn);
        controlP.add(TFresults);
        
        panelplease.add(controlP);
        //basePanel.add(playerInformation(), BorderLayout.EAST);
        basePanel.add(panelplease, BorderLayout.EAST);
        //ADD CONTROL PANEL HERE
       // basePanel.add(controlMenu(), BorderLayout.SOUTH);
        
        frame.add(basePanel);
        frame.pack();
        frame.setVisible(true);        
    }
    
     
     //CONVERT TO JPANEL
    public void setupMenu(){

        Text space1 = new Text("                  ");
        Text space2 = new Text("                  ");
        Text space3 = new Text("                 ");
        Text space4 = new Text("                                                 ");
        Text space5 = new Text("                                               ");
        
        Text text1 = new Text("Lets set up the game. \n Please select number of players and choose a tokin.\n Number of players allowed 2-4. \n \n Amount of Players:");
        TextField numberResponse = new TextField();
        Text txtP1 = new Text("Player One Name:  ");
        Text txtP2 = new Text("Player Two Name:  ");
        Text txtP3 = new Text("Player Three Name:  ");
        Text txtP4 = new Text("Player Four Name:  ");
        TextField TFplayer1 = new TextField();
        TextField TFplayer2 = new TextField();
        TextField TFplayer3 = new TextField();
        TextField TFplayer4 = new TextField();
        Text text2 = new Text("\n Next, select tokins: Fadora, Laptop, Rocket, Horse, Beaker, Glasses          \n");
        Text text15 = new Text("                                                            \n");
        Text txtTime = new Text("Please select a time alotment for each player's turn: ");
        TextField TFTime = new TextField();
        Button btnfinish = new Button("Finish");
        
         btnfinish.setOnAction(new EventHandler<ActionEvent>() {
          Stage setupMenu = new Stage();
             String player1Name = "one";
             String player2Name = "two";
             String player3Name = "thee";
             String player4Name = "four";
             String stringPlayerAmount;
             int numberOfPlayers;
             int timeAlotment;
            @Override
            public void handle(ActionEvent event) {
               player1Name = TFplayer1.getText();
               player2Name = TFplayer2.getText();
               player3Name = TFplayer3.getText();
               player4Name = TFplayer4.getText();
               stringPlayerAmount = numberResponse.getText();
               if("1".equals(stringPlayerAmount)){numberOfPlayers = 1;}
               if("2".equals(stringPlayerAmount)){numberOfPlayers = 2;}
               if("3".equals(stringPlayerAmount)){numberOfPlayers = 3;}
               if("4".equals(stringPlayerAmount)){numberOfPlayers = 4;}
               if(numberOfPlayers != 1 || numberOfPlayers != 2 || numberOfPlayers != 3 || numberOfPlayers != 4){
                 Error_Window("An invalid amount of players was entered.");
                 setupMenu();
              }
               if(numberOfPlayers == 1 || numberOfPlayers == 2 || numberOfPlayers == 3 || numberOfPlayers == 4){
                 gameBoard = new Board(numberOfPlayers, player1Name, player2Name, player3Name, player4Name, timeAlotment, 17);
               viewBoard(gameBoard.get_Player(0));
              }        
            }
        });
        
         //Adding Children to Root
        FlowPane root = new FlowPane(); root.getChildren().add(text1);  root.getChildren().add(numberResponse);
        root.getChildren().add(text15); root.getChildren().add(text2); root.getChildren().add(txtP1);
        root.getChildren().add(TFplayer1); root.getChildren().add(space1); root.getChildren().add(txtP2);
        root.getChildren().add(TFplayer2); root.getChildren().add(space2); root.getChildren().add(txtP3);
        root.getChildren().add(TFplayer3); root.getChildren().add(space3); root.getChildren().add(txtP4);
        root.getChildren().add(TFplayer4); root.getChildren().add(space4); root.getChildren().add(txtTime);
        root.getChildren().add(TFTime); root.getChildren().add(space5); root.getChildren().add(btnfinish);

        Scene setupScene = new Scene(root, 400, 350);

        Stage setupMenu = new Stage();
        setupMenu.setTitle("Setup Menu");
        setupMenu.setScene(setupScene);
        setupMenu.show();        
    }
    
    
    public JPanel playerInformation(){
        JFrame frame = new JFrame();
        JPanel allPanel = new JPanel();
        allPanel.setPreferredSize(new Dimension(350,1200));
        
        for(int i =0; i < 4; i++){
          allPanel.add(PlayerPanel(gameBoard.get_Player(i)));  
        }
        return allPanel;
    }

      public JPanel PlayerPanel(Player player){

        JPanel playerPanel = new JPanel();
        playerPanel.setPreferredSize(new Dimension(300,150));
        //Player One Image Panel
        JPanel ImagePanel = new JPanel();
        ImagePanel.setPreferredSize(new Dimension(100,100));
        JLabel photoLabel3 = new JLabel(player.Get_Image());
        ImagePanel.add(photoLabel3);
        
        //Player One Data Panel
        JPanel DataPanel = new JPanel();
        DataPanel.setPreferredSize(new Dimension(150,150));
        JLabel playerThreeName = new JLabel(player.Get_Name());
        JTextField account3 = new JTextField( "" +player.Get_Money());
        JComboBox playerThreeProp = new JComboBox();
        DataPanel.add(playerThreeName);
        DataPanel.add(account3);
        DataPanel.add(playerThreeProp);
        
        //Layering Panels
        playerPanel.add(ImagePanel);
        playerPanel.add(DataPanel);
        
        return playerPanel;
    }
   
      
       public void managePropertyMenu(){
       JFrame frame = new JFrame("Manage Property");
       JPanel basePanel = new JPanel();
       JButton buyP = new JButton("Buy Property");
       JButton morgageP = new JButton("Morgage Property");
       JButton tradeP = new JButton("Trade Property");
       basePanel.setLayout(new FlowLayout());
       basePanel.add(buyP); basePanel.add(morgageP); basePanel.add(tradeP);
       
       frame.add(basePanel);
       frame.pack();
       frame.setVisible(true); 
       }
       
       public void playerTurns(){
           viewBoard(gameBoard.get_Player(turnCounter));
       }
       
       public void Error_Window(String message){
       JFrame frame = new JFrame("ERROR");
       frame.setSize(300, 300);
       JPanel basePanel = new JPanel();
       JLabel errorTxt = new JLabel(message);
       basePanel.setLayout(new FlowLayout());
       basePanel.add(errorTxt);
       
       frame.add(basePanel);
       frame.pack();
       frame.setVisible(true); 
       }
}
