/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package monopolydriver;


/**
 * @author Sean Mitchel
 * This class contains the Other_Tile class. It is for the "Buy Books" and "Pay
 * Tuition" tiles on the game board.
 */
public class Other_Tile 
{
    private int flag = 0;
    private String name;
    private String location;
	private String cost;
    private boolean hasEvent = true;
    
    /**
     * Class constructor
     * @author Sean Mitchell
     * 
     * @param name
     * @param location
     * @param cost 
     */
    Other_Tile (String name, String location, String cost)
    {        
        this.name = name;
        this.location = location;
	this.cost = cost;

	switch(this.name)
	{
	    case "Buy Books":
		this.flag = 1;
		break;
	    case "Pay Tutition":
		this.flag = 2;
		break;
	default:
		break;
	}
    }
    
    /**
     * Returns the name of the Property
     * @author Ansley Solomon
     * @return String name
     */
    public String getName(){
        return this.name;
    }

    /**
     * Returns the Property's location on the Board
     * @author Ansley Solomon
     * @return int location
     */
    public int getLocation(){
        int lo = Integer.parseInt(location);	
        return lo;
    }

     /**
     * Returns the tile's cost
     * @author Ansley Solomon
     * @return Returns the tile's cost
     */
    public int getCost(){
	        int co = Integer.parseInt(this.cost);	
	        return co;
	}
    
    /**
     * Returns if the tile has an event
     * @author Sean Mitchell
     * @return boolean hasEvent
     */
    public boolean getHasEvent()
    {
        return this.hasEvent;
    }

    /**
     * Returns the text that displays when the tile has an event
     * @author Sean Mitchell
     * @return String text
     */
    String getEventText() {
        return "no event";
    }
}
