
package monopolydriver;
// ========================================
// Player.java
// Main class for the player objects
// ========================================

// Imports
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.swing.ImageIcon;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
import javax.imageio.ImageIO;
import javax.swing.JLabel;

public class Player{
	// Member Variables

	private int location;
	private int money;

        ArrayList<Tile_Adapter> property_list = new ArrayList<>();
	private ImageIcon image;
	private String name;
	private boolean is_ready;
        private boolean playable;

	// Default constructor
        /**
         * Player constructor
         * @param input_name  - assigned as players name
         * @param whichP     -  determines player's ImageIcon 
         */
	public Player(String input_name, int whichP)
	{
            System.out.print("Player created!\n");

	    location = 0;		// starting location
            name = input_name;	// player name as a string
	    money = 1500;		// temp variable, this will change
	    is_ready = false;	// is the player ready to move to the next
            playable = true;
             
            //depending on whichp value determines the Player's Image Icon
             if(whichP == 1){
                 //get Image
                 File imageFile = new File("Fadora.PNG");
                 BufferedImage tokinImage = new BufferedImage(50, 50, BufferedImage.TYPE_INT_ARGB);
                 try{
                    tokinImage = ImageIO.read(imageFile);
                    } 
                catch(IOException e){
                    System.out.println("Error: " + e);
                    }
            image = new ImageIcon(tokinImage);
            }
             if(whichP == 2){
                 //get image
                 File imageFile = new File("Beaker.PNG");
                 BufferedImage tokinImage = new BufferedImage(50, 50, BufferedImage.TYPE_INT_ARGB);
                 try{
                    tokinImage = ImageIO.read(imageFile);
                    } 
                catch(IOException e){
                    System.out.println("Error: " + e);
                    }
            image = new ImageIcon(tokinImage);
            }
             if(whichP == 3){
                 //get image
                 File imageFile = new File("Glasses.PNG");
                 BufferedImage tokinImage = new BufferedImage(50, 50, BufferedImage.TYPE_INT_ARGB);
                 try{
                    tokinImage = ImageIO.read(imageFile);
                    } 
                catch(IOException e){
                    System.out.println("Error: " + e);
                    }
            image = new ImageIcon(tokinImage);
            }
             if(whichP != 1 && whichP != 2 && whichP != 3){
                 //get image
                 File imageFile = new File("Horse.PNG");
                 BufferedImage tokinImage = new BufferedImage(50, 50, BufferedImage.TYPE_INT_ARGB);
                 try{
                    tokinImage = ImageIO.read(imageFile);
                    } 
                catch(IOException e){
                    System.out.println("Error: " + e);
                    }
            image = new ImageIcon(tokinImage);
            }
	} 

	// ==================================
	// Accessor Functions
	// ==================================
	
        /**
         * Get_Location()
         * Returns the Player's current location as an int
         * @author Sean Mitchel
         * @return int location
         */
	public int Get_Location(){
                return this.location;
	}
	
        /**
         * Get_Money()
         * Returns current player money as an int
         * @author Sean Mitchel
         * @return Location
         */
	public int Get_Money(){
               return this.money;
	}
        
        /**
         * Get_Name()
         * Returns a Player's name as a String
         * @author Sean Mitchel
         * @return 
         */
	public String Get_Name(){
            return this. name;
	}

	/**
         * Is_Ready()
         * Tells if a Player is ready to take their turn
         * @author Sean Mitchel
         * @return boolean is_ready
         */
	public boolean Is_Ready(){
            return this.is_ready;
        }
        
         /**
          * Get_Image()
         * Returns a Player's token
         * @author 
         * @return ImageIcon image
         */
        public ImageIcon Get_Image(){
            return this.image;
        }
        
        /**
         * Get_YCordinate()
         * Based on the player's location the function returns what the corresponding Y coordinate 
         * should be on the board for GUI board display
         * @author Megan Haskins
         * @return int
         */
        public int Get_YCordinate(){
        int starty = 545;
        if(Get_Location() < 10 && Get_Location() >= 0){ 
            Dice_Roller Shift_Roller = new Dice_Roller(50);
                return starty + Shift_Roller.Roll();
        }
        if(Get_Location() < 30 && Get_Location() > 20 ){
 
            Dice_Roller Shift_Roller = new Dice_Roller(50);
            return 50 + Shift_Roller.Roll();
        }
        if(Get_Location() == 10){return 550;}
        if(Get_Location() == 11){ return 500;}
        if(Get_Location() == 12){ return 470;}
        if(Get_Location() == 13){ return 415;}
        if(Get_Location() == 14){ return 370;}
        if(Get_Location() == 15){ return 300;}
        if(Get_Location() == 16){ return 265;}
        if(Get_Location() == 17){ return 215;}
        if(Get_Location() == 18){return 190;}
        if(Get_Location() == 19){ return 100;}
        if(Get_Location() == 20){return 50;}
        if(Get_Location() == 31){ return 100;}
        if(Get_Location() == 32){ return 190;}
        if(Get_Location() == 33){ return 235;}
        if(Get_Location() == 34){ return 265;}
        if(Get_Location() == 35){ return 300;}
        if(Get_Location() == 36){ return 370;}
        if(Get_Location() == 37){ return 415;}
        if(Get_Location() == 37){ return 450;}
        if(Get_Location() == 39){ return 500;}
        if(Get_Location() == 40 || Get_Location() == 0){return 545;}
       
               
            return 0;
        }
        
        /**
         * Get_XCordinate()
         * Based on the player's location the function returns what the corresponding X coordinate 
         * should be on the board for GUI board display
         * @author Megan Haskins
         * @return int
         */
        public int Get_XCordinate(){
            int startx = 750;
            if(Get_Location() == 20){return 170;}
            if(Get_Location() == 0){ return startx;}
            if(Get_Location() == 1 ){
                return 655;
            }
            if(Get_Location() == 29){return 650;}
            if(Get_Location() == 2){
                return 590;
            }
            if(Get_Location() == 28){return 590;}
            if(Get_Location() == 3) {
                return 530; 
            }
            if(Get_Location() == 27){return 555;}
            if(Get_Location() == 4 || Get_Location() == 26){return 500;}
            if(Get_Location() == 5 || Get_Location() == 25){return 420;}
            if(Get_Location() == 6 || Get_Location() == 24){return 365;}
            if(Get_Location() == 7 || Get_Location() == 23){return 315;}
            if(Get_Location() == 8 || Get_Location() == 22){return 260;}
            if(Get_Location() == 9 || Get_Location() == 21){return 220;}
            if(Get_Location() == 10){
                return 160;
            }
            
            if(Get_Location() >= 10 && location < 20){
                Dice_Roller Shift_Roller = new Dice_Roller(50);
                return 120 + Shift_Roller.Roll();
            }
            if(Get_Location() >= 30 && location < 40){
                Dice_Roller Shift_Roller = new Dice_Roller(50);
                return 720 + Shift_Roller.Roll();
            }
            return 0;
        }

         /**
          * Get_Property_Amount()
         * Returns the size of property_list
         * @author Megan Haskins
         * @return int
         */
	public int Get_Property_Amount(){
            return property_list.size();
        }

	// ==================================
	// Mutator Functions
	// ==================================
     
	/**
         * Set_LOcation(int input)
	* Sets the player's location as an int
	*
	* @param  input  an integer representing the location of the player
	* @return      None
	*/
	public void Set_Location(int input){
            location = input;
	}
        
        /**
         * Shift_Location
	* changes a players location based on a value passed in
        * @author Megan Haskins
	* @param  	shift  The amount to shift the player's location by
	*/
        public void Shift_Location(int input){
             location = location + input;
            if(location >= 40){
                location = location -40;
                this.shift_Money(200);
            }
        }

	/**
         * Set_Money(int input)
	* Sets the player's money to the given input
	* @author Sean Mitchel
	* @param  input  an integer representing the player's money
	* @return      None
	*/
	public void Set_Money(int input)
	{
        	money = input;
	}
        
        /**
         * shift_Money(int input)
	* shifts a player's money (add/subtraction)
        * @author Megan Haskins
	* @param  	input  The amount to shift the player's location by
	*/
        public void shift_Money(int input){
            money = money + input;
        }

	/**
         * Set_Name(String input)
	* Sets the player's name to the given input
	*
	* @param  input  a string representing the player's name
	* @return      None
	*/
	public void Set_Name(String input){
            name = input;
	}

	
	/**
	* Sets if the player is ready to end their turn
	*
	* @param  	None
	* @return      	None
	*/
	public void Set_Ready(){
            is_ready = true;
	}
        
        /**
         * Get_Tile(int index)
         * returns a Tile_Adapter from property list. The index of the tile is specified by the int index parameter
         * @param index
         *  @author Megan Haskins
         * @return Tile_Adapter   
         */
        public Tile_Adapter Get_Tile(int index){
            return property_list.get(index);
        }
        
	/**
	* Sets the image used for the player's token
	*
	* @param  	x	A loaded image file
	* @return      	None
	*/
        public void Set_Image(ImageIcon x){
            image = x;
        }
/**
	* Allows the player to buy a property
	* Adds the property object to the player's property list 
	* and subtracts the cost of the property from the player's current money
	*
	* @param  	tile	A property object
	* @return      	None
	*/
	public void Buy_Property(Tile_Adapter tile){
            if (tile.Get_IsBuyable()) {                              
                property_list.add(tile);   
                tile.Set_IsOwned(true);
                tile.Set_Owner(this.name);
                money = money - tile.getPrice();
            }
            else
                System.out.print("Property is already owned!\n"); 
        }

	/**
	* Allows the player to sell a property
	* Removes the property object to the player's property list 
	* and adds the cost of the property from the player's current money
	*
	* @param  	tile	A property object
	* @return      	None
	*/
	public void Sell_Property(Tile_Adapter tile){
            System.out.print("Sell detected!\n");
            property_list.remove(tile);
            money = money + tile.getPrice();
	}
     /**
      * Trade_Property(Player Pother, Tile_Adapter tile)
      * Allows this player to sell a specified tile passed in through the parameter and then 
      * allows a different player passed in through the parameter to buy the same tile
      * @param p_other
      * @param tile 
      * @author Sean Mitchel
      */
	public void Trade_Property(Player p_other, Tile_Adapter tile){
		Sell_Property(tile);
		p_other.Buy_Property(tile);	
	}
        
        /**
         * Swap_Property(Tile_Adapter tile1, Tile_Adapter tile2, Player p_other )
         * Allows two players to trade property. 
         * @param tile1  tile that this player is getting rid of and giving to Player p_other
         * @param tile2  tile that PLayer p_other is getting rid of and giving to this player
         * @param p_other Player that this player will be making the property swap with
         * @author Megan Haskins
         */
        public void Swap_Property(Tile_Adapter tile1, Tile_Adapter tile2, Player p_other ){
            this.property_list.add(tile2); 
            p_other.property_list.remove(tile2);
            p_other.property_list.add(tile1);
            this.property_list.remove(tile1);
        }
        
        /**
         * Get_Property_Name(int index)
         * Returns a property name from property_list. The property name to be returned is specified by the param index.
         * @param index
         * @author Megan Haskins
         * @return String
         */
         public String Get_Property_Name(int index){  
            return property_list.get(index).getName();
         }
         
        
        /**
         * Turn()
         * Keeps track of current players turn options and user selection
         * Used in non JFrame/JPanel implementation
         * @author Sean Mitchel
         */
        public void Turn()
	{
		String s = "";
		System.out.print("Actions: Buy | Sell | Trade\n");
		Scanner sc = new Scanner(System.in);
		s = sc.nextLine();
		if (s.equals("Buy")){System.out.print("Buy detected!\n");}
		else if (s.equals("Sell")){System.out.print("Sell detected!\n");}
		else if (s.equals("Trade")){System.out.print("Trade detected!\n");}
	}
     
         /**
          * PlayerRoll()
          * Rolls the dice for a player and returns the roll as an int.
          * @return rollValue
          * @author Megan Haskins
          */
        public int PlayerRoll(){
            int rollValue = (new Dice_Roller(12).Roll());
           // Shift_Location(rollValue);
            System.out.println("The Player Rolled a: "+ rollValue);
            this.Shift_Location(rollValue);
            return rollValue;
        }

        /**
         * Get_Total_Worth()
         * returns the calculated amount of a players account balance plus the value of all their properties
         * @return worth
         * @author Megan Haskins
         */
    public int Get_Total_Worth() {
        int worth = this.Get_Money();
            for(int i = 0; i < this.Get_Property_Amount(); i++){
                worth = worth + property_list.get(i).getPrice();
            }
            return worth;
    }
    
     /**
     * Update_Playability()
     * returns if a player is playable after checking and updating if a player is updatable
     * @return playable value
     * @author Megan Haskins
     */
    public boolean Update_Playability(){
        if(this.Get_Money() < 0){
            this.Set_Playable(false);
            return false;
        }
        else{
            return true;
        }
    }
    
    /**
     * Set_Playable(boolean tf)
     * sets playable to the boolean value entered in the param
     * @param tf boolean true or false
     * @author Megan Haskins
     */
    public void Set_Playable(boolean tf){
        playable = tf;
    }
    
    /**
     * Get_Playable( )
     * returns value of playable
     * @author Megan Haskins
     * @return playable
     */
    public boolean Get_Playable(){
        return playable;
    }
    
}