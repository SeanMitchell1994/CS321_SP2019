
package monopolydriver;

/**
 * Card class
 * 
 * This class contains the card object and methods to access the individual
 * card components. 
 * 
 * @author Ansley Solomon, Sean Mitchell
 */
public class Card
{
	private final String card_type;
	private final String card_id;
	//private final Card_Event event;
	private final String text;
        private final String event_type;
        private final String event_value;
        /**
     * @author Sean Mitchell, Ansley Solomon
     * Default construct for a card object
     *
     * @param card_id_input The card's ID number
     * @param text_input The card's text
     * @param type_input The card's type (chance or charger chest)
     * @param event_type_input The type of event the card performs
     * @param event_value_input The value that goes in the even function
     * @return None
     *
        */
	public Card(String card_id_input, String text_input, String type_input, String event_type_input, String event_value_input)
	{
		//event = event_input;
		card_id = card_id_input;
		text = text_input;
                card_type = type_input;
                event_type = event_type_input;
                event_value = event_value_input;
	}


    /**
    * Author: Ansley Solomon
    * getCardType()
    * Returns a card's type as a string.
    * @return   String   card_type
    */
    public String getCardType()
    {
            return card_type;
    }
    /**
    * @author Ansley Solomon
    * getID()
    * Returns a card's ID as a int.
    * @return   int   card id
    */
    public int getID()
    {
        int id = Integer.parseInt(card_id);
        return id;
    }
    /**
    * @author Ansley Solomon
    * getText()
    * Returns a card's text as a String.
    * @return   String   text
    */
    public String getText(){
        return text;
    }
    
     /**
    * @author Ansley Solomon
    * getEventType()
    * Returns a card's event_type as a String.
    * @return   String   event_type
    */
    public String getEventType()
    {
        return event_type;
    }
     /**
    * @author Ansley Solomon
    * getEventValue()
    * Returns a card's event_value as a String.
    * @return   String   event_value
    */
    public String getEventValue()
    {
        return event_value;
    }

    /** @author Sean Mitchel
     *  Get_Event(Player input)
     *  Implements an event card on a player passed in
     * 
     * @param input 
     */

    public void Get_Event(Player input)
    {
        if (this.getEventType().equals("collect"))
        {
            input.shift_Money(Integer.parseInt(this.getEventValue()));
        }
        else if (this.getEventType().equals("move"))
        {
            input.Set_Location(Integer.parseInt(this.getEventValue()));
        }
    }     
}