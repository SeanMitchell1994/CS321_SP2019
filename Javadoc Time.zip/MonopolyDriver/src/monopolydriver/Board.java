/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package monopolydriver;
// ========================================
// Board.java
// Main class for the board objects
// ========================================



// Imports
import java.util.LinkedList;
public class Board{
    
     // ========================================================
     // Member variables
     // ========================================================
    private static Board instance = null;

    private final Dice_Roller dice = new Dice_Roller(6);					        // dice object
    private final LinkedList<Player> player_list = new LinkedList<Player>();		                 // linked list with player object
    private final LinkedList<Property_Tile> property_list = new LinkedList<Property_Tile>();		// linked list with property objects
    private final Tile_Adapter board[] = new Tile_Adapter[40];

    private PropertyList pl = new PropertyList();
    private Decks d1 = new Decks();
    private int[] scoreboard;								// array containing the total score of each player
    private int turn_flag = 0;								// integer flag identifying whose turn it is
    private int NUM_PLAYERS;								// integer flag identifying whose turn it is
    private int turn_time;
    private int turn_amount;
    private int remaining_players;

    
/**
* Default constructor for Board objects
*
* @param  	None  
* @return      	A Board object
*/
    protected Board(){
        System.out.print("Board created!\n");
	Board_Init();      
	}

 /**
* Board(int playerAmount, String p1, String p2, String p3, String p4, int turns)
* Protected constructor for Board objects
* @param  	int                playerAmount - amount of Players for the game     
* @param        String             String p1 - Player one name
* @param        String             String p2 - Player two name
* @param        String             String p3 - Player three name
* @param        String             String p4 - Player four name
* @param        int                turns - amount of turn sequences to allow the game
* @return      	A Board object
*/
    protected Board(int playerAmount, String p1, String p2, String p3, String p4, int turns){
        String names[];
        names = new String[] {p1, p2, p3, p4};
        for(int i = 0; i < playerAmount; i++){
            instance.player_list.add(new Player(names[i], (i+1)));
        }
        instance.turn_time = 100;
        instance.turn_amount = turns;
        instance.Board_Init();
        instance.remaining_players = 4;    
        }
    
    
/**
* Get_Instance(int playerAmount, String p1, String p2, String p3, String p4, int turns)
* Returns Board instance
* If board instance had not been initialized board instance is instantiated
* @param  	int                playerAmount - amount of Players for the game     
* @param        String             String p1 - Player one name
* @param        String             String p2 - Player two name
* @param        String             String p3 - Player three name
* @param        String             String p4 - Player four name
* @param        int                turns - amount of turn sequences to allow the game
* @return      	A Board object
*/
    public static Board Get_Instance(int playerAmount, String p1, String p2, String p3, String p4, int turns){
        if(instance == null) {
            instance = new Board(playerAmount, p1, p2, p3, p4, turns*4);
            return instance;
            }
            return instance;
        }
     
    
/**
* Get_Instance()
* Returns Board instance
* If board instance had not been initialized board instance is instantiated
* @return      	A Board object
*/
    public static Board Get_Instance(){
        if(instance == null) {
            instance = new Board();
            return instance;
        }
        return instance;
        }
     
/**
* Board Get_Instance(String p1, String p2, String p3, String p4)
* Returns Board instance
* If board instance had not been initialized board instance is instantiated
* @return      	A Board object
*/
    public static Board Get_Instance(String p1, String p2, String p3, String p4){
        if(instance == null) {
            instance = new Board();
            String names[];
            names = new String[] {p1, p2, p3, p4};
            for(int i = 0; i < 4; i++){
                instance.player_list.add(new Player(names[i], (i+1)));
            }
            return instance;
        }
            return instance;
    }
       
    /**
    * Initialize utility function for board objects, called on object creation
    * Main purpose is to call other functions and populate member variables
    *
    * @param  	None  
    * @author   Sean Mitchel
    * @return      	None
    */
    private void Board_Init(){
        //pl.Get_Property();
        //pl.Get_CW();
        //pl.Get_U();
        System.out.println("Properties tiles!");
        for (int i = 0; i < pl.Get_Property().size(); i++){
            //System.out.print(i);
            board[pl.Get_Property().get(i).getLocation()] = new Tile_Adapter(pl.Get_Property().get(i));
        }    
        System.out.println("CW tiles!");
        for (int i = 0; i < pl.Get_CW().size(); i++){
            //System.out.print(pl.Get_CW().get(i).getLocation()+"\n");
            board[pl.Get_CW().get(i).getLocation()] = new Tile_Adapter(pl.Get_CW().get(i));
        }    
        System.out.println("Utility tiles!");
        for (int i = 0; i < pl.Get_U().size(); i++){
            //System.out.print(i);
            board[pl.Get_U().get(i).getLocation()] = new Tile_Adapter(pl.Get_U().get(i));
        }    
        System.out.println("Charger Chest tiles!");
        for (int i = 0; i < pl.Get_CC().size(); i++){
            //System.out.print(i);
            board[pl.Get_CC().get(i).getLocation()] = new Tile_Adapter(pl.Get_CC().get(i));
        }            
        System.out.println("Chance tiles!");
        for (int i = 0; i < pl.Get_C().size(); i++){
            //System.out.print(i);
            board[pl.Get_C().get(i).getLocation()] = new Tile_Adapter(pl.Get_C().get(i));
        }    
        System.out.println("Corner tiles!");
        for (int i = 0; i < pl.Get_CT().size(); i++){
            //System.out.print(i);
            board[pl.Get_CT().get(i).getLocation()] = new Tile_Adapter(pl.Get_CT().get(i));
        }
        System.out.println("Other tiles!");
        for (int i = 0; i < pl.Get_OT().size(); i++){
            //System.out.print(i);
            board[pl.Get_OT().get(i).getLocation()] = new Tile_Adapter(pl.Get_OT().get(i));
        }
        System.out.println("Wha is in board");
        for(int i = 0; i<10; i++){
            System.out.println(board[i].getName());
	}
    }
	/**
	* Main function to update the events of the board
	* Calls various other functions on each player that need to happen each turn
	* @author       Sean
	* @param  	None  
	* @return      	None
	*/
    public void Update(){
	// updates all the dynamic varibles of the game
	Player_Turn(turn_flag);
        if (instance.turn_flag < 3){
            turn_flag++;
        }
        else{
            turn_flag = 0;
        }
    }
    
    /**
    *Get_Remaining_players()
    * returns the amount of Players still in play
    * @return	int    remaining_players
    */
    public int Get_Remaining_players(){
        return remaining_players;
    }
    
    /**
    * Set_Remaining_Players(int players)
    * sets the class variable remaining players to the param value passed in
    * @param	int    players - remaining_players
    */
    public void Set_Remaining_Players(int players){
        remaining_players = players;
    }
    
    /**
    * Calls the turn() on each player in the player_list
    *
    * @param  	turn_flag	Identifier of which player's turn it is
    * @return      	None
    */
    private void Player_Turn(int turn_flag){
	// Walks through player list and calls their turn
	System.out.printf("Player: %-5s |", instance.player_list.get(turn_flag).Get_Name());
	player_list.get(turn_flag).Turn();		
	}
    
    
    /**
	* Player get_Player(int index)
	* Returns a player from player_list. The player returned is specified by the index passed.
	* @author       Megan Haskins
	* @param  	int    index - index to retrieve a player from player_list  
	* @return      	Player
	*/
    public Player get_Player(int index){        
            return player_list.get(index);
        }
    
    /**
	* Property_Tile Get_Property(int index)
	* Returns a property_tile from property_list. Which property is returned is specified by the index passed.
	* @author       Megan Haskins
	* @param  	int    index - index to retrieve a player from player_list  
	* @return      	Property_Tile
	*/
    public Property_Tile Get_Property(int index){
        return property_list.get(index);
    }        
    
    
    /**
	* Tile_Adapter Get_Tile(int index)
	* Returns Tile_Adapter from board[]. Which Tile_Adapter is returned is specified by the index passed.
	* @author       Megan Haskins
	* @param  	int    index - index to retrieve a player from player_list  
	* @return      	Tile_Adapter
	*/
    public Tile_Adapter Get_Tile(int index){
        return board[index];
    }
      
    /**
	* Tile_Adapter Get_Board(int index)
	* Returns Tile_Adapter from board[]. Which Tile_Adapter is returned is specified by the index passed.
	* @author       Sean Mitchel
	* @param  	int    index - index to retrieve a player from player_list  
	* @return      	Tile_Adapter
	*/
    public Tile_Adapter Get_Board(int index){
        return board[index];
    }
        
    /**
	* String Create_Event(Player currentP)
	* Calls an event card based on a players location and returns the event text as a string
	* @author       Megan Haskins
	* @param  	Player    currentP - current player at turn execution 
	* @return      	String    event message for event generated in function
	*/
    public String Create_Event(Player currentP){
        board[currentP.Get_Location()].getEvent(currentP);
        if(currentP.Get_Location() == 2){
            return "Buy Textbooks: -$250";
        }
        if(currentP.Get_Location() == 38){
            return "Pay Tuition: -$250";
        }            
        return board[currentP.Get_Location()].getEventText();
        }

}
