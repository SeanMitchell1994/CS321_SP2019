/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package monopolydriver;
// ========================================
// Board.java
// Main class for the board objects
// ========================================



// Imports
import java.util.LinkedList;
public class Board{

	// Member variables
	//private final Card_Factory c_factory = new Card_Factory();				// card factory
	//private final Tile_Factory t_factory = new Tile_Factory();				// property factory
	private final Dice_Roller dice = new Dice_Roller(6);					// dice object
	private final LinkedList<Player> player_list = new LinkedList<Player>();		// linked list with player object
	private final LinkedList<Property_Tile> property_list = new LinkedList<Property_Tile>();		// linked list with property objects
        private final Tile_Adapter board[] = new Tile_Adapter[40];
	//private final LinkedList<Card> chance_list = new LinkedList<Card>();			// linked list with chance cards
	//private final LinkedList<Card> community_list = new LinkedList<Card>();		// linked list with community cards


	//private final LinkedList<Card> chance_list = new LinkedList<Card>();			// linked list with chance cards

	//private final LinkedList<Card> community_list = new LinkedList<Card>();		// linked list with community cards

        private PropertyList pl = new PropertyList();
        private Decks d1 = new Decks();
	private int[] scoreboard;								// array containing the total score of each player
	private int turn_flag = 0;								// integer flag identifying whose turn it is
        private int NUM_PLAYERS;								// integer flag identifying whose turn it is
        private int turn_time;
        private int turn_amount;
        private int remaining_players;

	/**
	* Default constructor for Board objects
	*
	* @param  	None  
	* @return      	A Board object
	*/
	public Board(){
		System.out.print("Board created!\n");
		Board_Init();      
	}
        
        public Board(int playerAmount, String p1, String p2, String p3, String p4, int time, int turns){
            String names[];
            names = new String[] {p1, p2, p3, p4};
            for(int i = 0; i < playerAmount; i++){
                player_list.add(new Player(names[i], (i+1)));
            }
            turn_time = time;
            turn_amount = turns;
            Board_Init();
            remaining_players = 4;
            
        }
        
        public Board(String p1, String p2, String p3, String p4){
            String names[];
            names = new String[] {p1, p2, p3, p4};
            for(int i = 0; i < 4; i++){
                player_list.add(new Player(names[i], (i+1)));
            }
            Board_Init();
            
        }
       
        private void Board_Init(){
       
            //pl.Get_Property();
            //pl.Get_CW();
            //pl.Get_U();

            System.out.println("Properties tiles!");
            for (int i = 0; i < pl.Get_Property().size(); i++)
            {
                //System.out.print(i);
                board[pl.Get_Property().get(i).getLocation()] = new Tile_Adapter(pl.Get_Property().get(i));
            }
            
            System.out.println("CW tiles!");
            for (int i = 0; i < pl.Get_CW().size(); i++)
            {
                //System.out.print(pl.Get_CW().get(i).getLocation()+"\n");
                board[pl.Get_CW().get(i).getLocation()] = new Tile_Adapter(pl.Get_CW().get(i));
            }
            
            System.out.println("Utility tiles!");
            for (int i = 0; i < pl.Get_U().size(); i++)
            {
                //System.out.print(i);
                board[pl.Get_U().get(i).getLocation()] = new Tile_Adapter(pl.Get_U().get(i));
            }
            
            System.out.println("Charger Chest tiles!");
            for (int i = 0; i < pl.Get_CC().size(); i++)
            {
                //System.out.print(i);
                board[pl.Get_CC().get(i).getLocation()] = new Tile_Adapter(pl.Get_CC().get(i));
            }
            
            System.out.println("Chance tiles!");
            for (int i = 0; i < pl.Get_C().size(); i++)
            {
                //System.out.print(i);
                board[pl.Get_C().get(i).getLocation()] = new Tile_Adapter(pl.Get_C().get(i));
            }
            
            System.out.println("Corner tiles!");
            for (int i = 0; i < pl.Get_CT().size(); i++)
            {
                //System.out.print(i);
                board[pl.Get_CT().get(i).getLocation()] = new Tile_Adapter(pl.Get_CT().get(i));
            }

		System.out.println("Other tiles!");
           for (int i = 0; i < pl.Get_OT().size(); i++)
           {
                //System.out.print(i);
                board[pl.Get_OT().get(i).getLocation()] = new Tile_Adapter(pl.Get_OT().get(i));
            }
           System.out.println("Wha is in board");
                for(int i = 0; i<10; i++){
                System.out.println(board[i].getName());
	}
        }
	/**
	* Main function to update the events of the board
	* Calls various other functions on each player that need to happen each turn
	*
	* @param  	None  
	* @return      	None
	*/
	public void Update(){
		// updates all the dynamic varibles of the game
		Player_Turn(turn_flag);

		if (turn_flag < 3)
			turn_flag++;

		else
			turn_flag = 0;

	}

	/**
	* Gets all the scores of each player
	*
	* @param  	None  
	* @return      	The player's score
	*/
	public int Get_Score(){
		// Checks the score of each player and returns the scoreboard
		return 0;
	}
        
        public int Get_Remaining_players(){
            return remaining_players;
        }
        public void Set_Remaining_Players(int players){
            remaining_players = players;
        }

	/**
	* Calls the turn() on each player in the player_list
	*
	* @param  	turn_flag	Identifier of which player's turn it is
	* @return      	None
	*/
	private void Player_Turn(int turn_flag){

		// Walks through player list and calls their turn
		System.out.printf("Player: %-5s |", player_list.get(turn_flag).Get_Name());
		player_list.get(turn_flag).Turn();		

	}
        public Player get_Player(int index){
            
            return player_list.get(index);
        }
        
        public Property_Tile Get_Property(int index){
            return property_list.get(index);
        }
        
        public Tile_Adapter Get_Board(int index){
            return board[index];
        }
        
        public void Create_Event(Player currentP){
            board[currentP.Get_Location()].getEvent(currentP);
            System.out.println(board[currentP.Get_Location()].getEventText());
        }

}
