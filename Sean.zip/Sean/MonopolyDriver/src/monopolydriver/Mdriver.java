/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package monopolydriver;

import java.io.InputStream;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.stage.Stage;

/**
 *
 * @author MeganHaskins
 */
public class Mdriver extends Application {
   
    @Override
    public void start(Stage primaryStage) {
        
        InputStream holder = Mdriver.class.getClassLoader().getResourceAsStream("PracticeFile.txt");
        System.out.print("Main entry point!\n");

	System.out.print("Demo finished!\n");
        View1 trialView = new View1();
        trialView.welcomeMenu();
    }
    

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}

